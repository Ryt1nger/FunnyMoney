import test from 'node:test';
import assert from 'node:assert/strict';
import { RoadRunnerEngine } from './engine';
import { DEFAULT_CONFIG } from './config';
import type { Entity } from './types';

function seeded(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function place(e: RoadRunnerEngine, kind: Entity['kind'], lane: 0 | 1 | 2, obstacle: boolean): Entity {
  const ent: Entity = {
    id: 9000 + e.state.entities.length,
    kind,
    isObstacle: obstacle,
    lane,
    x: DEFAULT_CONFIG.laneCenters[lane],
    y: DEFAULT_CONFIG.bearY - 30,
    w: 60,
    h: 60,
    hit: 1,
  };
  e.state.entities.push(ent);
  return ent;
}

test('obstacle costs a life, gives invulnerability, three hits end the game', () => {
  const e = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(1));
  e.start();
  e.state.entities = [];
  place(e, 'box', 1, true);
  e.update(0.016);
  assert.equal(e.state.lives, 2);
  assert.ok(e.state.invulnLeft > 0.8);
  place(e, 'box', 1, true);
  e.update(0.016);
  assert.equal(e.state.lives, 2, 'invulnerable, no second hit');
  e.state.invulnLeft = 0;
  place(e, 'box', 1, true);
  e.update(0.016);
  e.state.invulnLeft = 0;
  place(e, 'box', 1, true);
  e.update(0.016);
  assert.equal(e.state.phase, 'over');
});

test('shield absorbs exactly one hit', () => {
  const e = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(2));
  e.start();
  e.state.entities = [];
  e.state.shieldLeft = 5;
  place(e, 'rocks', 1, true);
  e.update(0.016);
  assert.equal(e.state.lives, 3);
  assert.equal(e.state.shieldLeft, 0);
});

test('coins: +1 normally, +2 with double bonus', () => {
  const e = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(3));
  e.start();
  e.state.entities = [];
  place(e, 'coin', 1, false);
  e.update(0.016);
  assert.equal(e.state.coins, 1);
  e.state.doubleLeft = 5;
  place(e, 'coin', 1, false);
  e.update(0.016);
  assert.equal(e.state.coins, 3);
});

test('pickup bonuses set timers', () => {
  const e = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(4));
  e.start();
  e.state.entities = [];
  place(e, 'magnet', 1, false);
  place(e, 'double', 1, false);
  place(e, 'shield', 1, false);
  e.update(0.016);
  assert.ok(e.state.magnetLeft > 4 && e.state.doubleLeft > 5 && e.state.shieldLeft > 9);
});

test('magnet pulls coins from neighbouring lane', () => {
  const e = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(5));
  e.start();
  e.state.entities = [];
  e.state.magnetLeft = 5;
  const c = place(e, 'coin', 0, false);
  c.y = DEFAULT_CONFIG.bearY - 120;
  for (let i = 0; i < 30 && e.state.coins === 0; i++) e.update(0.016);
  assert.equal(e.state.coins, 1);
});

test('lane movement is clamped to 3 lanes', () => {
  const e = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(6));
  e.start();
  e.moveLeft(); e.moveLeft(); e.moveLeft();
  assert.equal(e.state.lane, 0);
  e.moveRight(); e.moveRight(); e.moveRight();
  assert.equal(e.state.lane, 2);
});

test('fairness: every spawned row leaves a free lane', () => {
  for (let seed = 1; seed <= 50; seed++) {
    const e = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(seed));
    e.start();
    const seen = new Map<number, Set<number>>();
    for (let i = 0; i < 60 * 90; i++) {
      e.state.lives = 3; // не даём умереть, проверяем только генерацию
      e.update(1 / 60);
      for (const en of e.state.entities) {
        if (!en.isObstacle) continue;
        const key = Math.round(en.y - e.state.distance * 0 + 0); // ряд определяем ниже
        void key;
      }
    }
    // Считаем препятствия по «рядам» (одинаковый y при спавне)
    const rows = new Map<number, Set<number>>();
    const e2 = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(seed));
    e2.start();
    for (let i = 0; i < 60 * 60; i++) {
      e2.state.lives = 3;
      e2.update(1 / 60);
      for (const en of e2.state.entities) {
        if (!en.isObstacle) continue;
        const k = Math.round((en.y - e2.state.distance) / 4);
        if (!rows.has(k)) rows.set(k, new Set());
        rows.get(k)!.add(en.lane);
      }
    }
    for (const lanes of rows.values()) assert.ok(lanes.size <= 2, `seed ${seed}: row blocks all lanes`);
    void seen;
  }
});

test('a dodging bot survives 3 minutes on every seed (game is beatable at max speed)', () => {
  for (let seed = 1; seed <= 40; seed++) {
    const e = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(seed));
    e.start();
    let firstHit = -1;
    for (let i = 0; i < 60 * 180 && e.state.phase === "playing"; i++) {
      if (firstHit < 0 && e.state.lives < 3) firstHit = e.state.time;
      // бот: смотрит вперёд, идёт к ближайшей безопасной полосе, не пересекая занятые в момент перехода
      const by = DEFAULT_CONFIG.bearY;
      const look = Math.max(300, e.state.speed * 0.65); // человек смотрит дальше на большой скорости
      const blocked = (lane: number, from: number, to: number) =>
        e.state.entities.some((en) => en.isObstacle && en.lane === lane && en.y < by + to && en.y > by - from);
      const cur = e.state.lane;
      if (blocked(cur, look, 60)) {
        const cands = ([0, 1, 2] as const)
          .filter((t) => t !== cur && !blocked(t, look, 60))
          .filter((t) => {
            const step = Math.sign(t - cur);
            for (let l = cur + step; l !== t; l += step) if (blocked(l, 110, 60)) return false;
            return true;
          })
          .sort((x, y) => Math.abs(x - cur) - Math.abs(y - cur));
        if (cands.length) e.setLane((cur + Math.sign(cands[0] - cur)) as 0 | 1 | 2);
      }
      e.update(1 / 60);
    }
    assert.equal(e.state.lives, 3, `seed ${seed}: bot lost a life at ${Math.round(firstHit)}s (speed ~${Math.round(e.state.speed)})`);
  }
});

test('heart restores one life, never above max', () => {
  const e = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(7));
  e.start();
  e.state.entities = [];
  e.state.lives = 1;
  place(e, 'heart', 1, false);
  e.update(0.016);
  assert.equal(e.state.lives, 2);
  place(e, 'heart', 1, false);
  e.update(0.016);
  assert.equal(e.state.lives, 3);
  place(e, 'heart', 1, false);
  e.update(0.016);
  assert.equal(e.state.lives, 3);
});

test('hearts spawn only when a life is missing', () => {
  const full = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(8));
  full.start();
  let seenFull = 0;
  for (let i = 0; i < 60 * 120; i++) {
    full.state.lives = 3;
    full.state.invulnLeft = 99;
    full.update(1 / 60);
    seenFull += full.state.entities.filter((en) => en.kind === 'heart').length;
  }
  assert.equal(seenFull, 0);
  const hurt = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(8));
  hurt.start();
  let seenHurt = 0;
  for (let i = 0; i < 60 * 120; i++) {
    hurt.state.lives = 2;
    hurt.state.invulnLeft = 99;
    hurt.update(1 / 60);
    if (hurt.state.entities.some((en) => en.kind === 'heart' && en.y < 0)) seenHurt++;
  }
  assert.ok(seenHurt > 0, 'hearts should appear when a life is missing');
});

test('obstacle share: min 50% at start, +1% per 5 m, capped at 85%', () => {
  const e = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(11));
  e.start();
  const at = (m: number) => {
    e.state.distance = m * DEFAULT_CONFIG.pxPerMeter;
    return Math.round(e.obstacleShare * 100);
  };
  assert.equal(at(0), 50);
  assert.equal(at(4), 50);
  assert.equal(at(5), 51);
  assert.equal(at(100), 70);
  assert.equal(at(175), 85);
  assert.equal(at(5000), 85);
});

test('speed grows with round time: base at 0 s, max after ramp, independent of distance', () => {
  const e = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(12));
  e.start();
  e.state.lives = 99;
  e.state.invulnLeft = 9999;
  e.update(1 / 60);
  assert.ok(Math.abs(e.state.speed - DEFAULT_CONFIG.baseSpeed) < 5);
  const speeds: number[] = [];
  for (let t = 1; t <= DEFAULT_CONFIG.speedRampSeconds + 5; t++) {
    for (let i = 0; i < 60; i++) e.update(1 / 60);
    if (t === 30 || t === 60) speeds.push(e.state.speed);
  }
  assert.ok(speeds[0] > DEFAULT_CONFIG.baseSpeed + 50 && speeds[0] < speeds[1]);
  assert.ok(Math.abs(e.state.speed - DEFAULT_CONFIG.maxSpeed) < 5);
});

test('a hit costs 25% of the coins collected in the round (rounded up)', () => {
  const e = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(13));
  e.start();
  e.state.entities = [];
  e.state.coins = 20;
  place(e, 'box', 1, true);
  e.update(0.016);
  assert.equal(e.state.coins, 15);
  e.state.invulnLeft = 0;
  e.state.coins = 1;
  place(e, 'box', 1, true);
  e.update(0.016);
  assert.equal(e.state.coins, 0);
});

test('shield hit does not cost coins', () => {
  const e = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(14));
  e.start();
  e.state.entities = [];
  e.state.coins = 20;
  e.state.shieldLeft = 5;
  place(e, 'box', 1, true);
  e.update(0.016);
  assert.equal(e.state.coins, 20);
});

test('bait coins exist: coins lying in an obstacle lane just behind the obstacle', () => {
  const e = new RoadRunnerEngine(DEFAULT_CONFIG, seeded(15));
  e.start();
  let bait = 0;
  for (let i = 0; i < 60 * 120; i++) {
    e.state.lives = 3;
    e.state.invulnLeft = 99;
    e.update(1 / 60);
    for (const c of e.state.entities) {
      if (c.kind !== 'coin') continue;
      if (e.state.entities.some((o) => o.isObstacle && o.lane === c.lane && Math.abs(o.y - c.y) < 200 && o.y > c.y)) bait++;
    }
  }
  assert.ok(bait > 0, 'bait coins should appear');
});
