# Мини-игра «Гонка мишки» (FunnyMoney)

Скопируйте папку `roadrunner/` в `src/features/minigame/roadrunner/`.

```tsx
import { RoadRunnerGame } from '@/features/minigame/roadrunner';

<RoadRunnerGame
  onFinish={({ coins }) => wallet.add(coins)}   // начислить монеты в экономику
  onExit={() => navigate('/')}
  onEvent={(e) => { /* звуки и Haptics: coin | hit | shield-block | powerup | gameover */ }}
  spriteUrls={{ coin: coinPng }}                 // подмена любого спрайта (coin, magnet, shield, double, bear, road...)
/>
```

- `engine.ts` — чистая логика без React (тесты: `npx tsx --test engine.test.ts`)
- `config.ts` — баланс: скорость, жизни, длительность бонусов, размеры и хитбоксы препятствий
- `renderer.ts` — рисование на canvas; `assets/` — спрайты (bear, road, 8 препятствий)
- Бонусы: щит (гасит один удар), магнит (притягивает монеты), x2 (двойные монеты)
- Нужны декларации `*.png/*.jpg/*.css` (в Vite уже есть через `vite/client`)
