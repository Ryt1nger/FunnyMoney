#!/usr/bin/env python3
"""Устанавливает урок 3 в репозиторий FunnyMoney.
Запуск из папки lesson3:  python3 apply.py /Users/a1111/Desktop/funnyMoney/FunnyMoney
Копирует LessonThree.tsx и assets/lesson3, подключает урок в Lessons.tsx (id 'piggy-bank').
Повторный запуск безопасен."""
import re, shutil, sys
from pathlib import Path

repo = Path(sys.argv[1]).expanduser()
here = Path(__file__).parent
shutil.copy(here / 'LessonThree.tsx', repo / 'src/pages/LessonThree.tsx')
shutil.copytree(here / 'assets/lesson3', repo / 'src/assets/lesson3', dirs_exist_ok=True)

p = repo / 'src/pages/Lessons.tsx'
s = p.read_text()
if 'LessonThree' in s:
    print('Lessons.tsx уже подключён'); sys.exit(0)
s = s.replace("import LessonTwo from './LessonTwo';", "import LessonTwo from './LessonTwo';\nimport LessonThree from './LessonThree';", 1)
m = re.search(r"  if \(activeLesson === 'needs-vs-wants'\) \{.*?\n  \}\n", s, re.S)
assert m, 'не нашёл ветку needs-vs-wants'
branch = ("  if (activeLesson === 'piggy-bank') {\n"
          "    return <LessonThree onPracticeComplete={() => rewardPractice('piggy-bank')} onBack={() => { onLessonTransition?.('exit'); setActiveLesson(null); onFullScreenChange?.(false); }} />;\n"
          "  }\n")
s = s[:m.end()] + branch + s[m.end():]
old = "lesson.id === 'what-is-money' || lesson.id === 'needs-vs-wants')"
assert old in s, 'не нашёл условие кнопки «Начать»'
s = s.replace(old, "lesson.id === 'what-is-money' || lesson.id === 'needs-vs-wants' || lesson.id === 'piggy-bank')", 1)
p.write_text(s)
print('Готово: урок 3 подключён')
